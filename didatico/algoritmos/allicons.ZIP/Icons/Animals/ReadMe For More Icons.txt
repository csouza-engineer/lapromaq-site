4/24/96

If you are using notepad, go to edit and select word wrap.

For more icons and updated information on how to use 256k icons in Windows95.
(and how to do cool things with them)

http://magic.intelligentresources.com

Plus there is other cool stuff sounds, movies, games and more.

Tony