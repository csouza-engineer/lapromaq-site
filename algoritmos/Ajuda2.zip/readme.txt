Arquivos da Ajuda em portugu�s
-----------------

Para instalar os arquivos da Ajuda em portugu�s favor clicar duas vezes em Instaler.bat em ambos disco1 e disco 2. Isto deve ser feito ap�s voc� ter 
instalado os arquivos da Ajuda do CD do Visual Basic.

Os arquivos da Ajuda em portugu�s que est�o parcialmente localizados s�o:
vb5.hlp
vb5ext.hlp 
vbenlr3.hlp

As duas instala��es instalar�o os arquivos da Ajuda parcialmente localizados no seguinte diret�rio (c:\temp\VB5help). 
Em seguida, voc� dever� copiar os seguintes arquivos da Ajuda para o seu  subdiret�rio da Ajuda no diret�rio de instala��o do Visual Basic 5.0
Isto resultar� na superposi��o dos arquivos da Ajuda em portugu�s aos arquivos da Ajuda em ingl�s.
ie. Se instalar o Visual Basic 5.0 no diret�rio padr�o, (Arquivos de programa\DevStudio\VB) voc� deve copiar o

    conte�do do diret�rio c:\temp\VB5help para o c:\Arquivos de programa\DevStudio\VB\Diret�rio da Ajuda

Os arquivos s�o os seguintes:

vb5.hlp		vb5.cnt
vb5ext.hlp 	vb5ext.cnt
vbenlr3.hlp	vbenlr3.cnt

Ap�s sobrescrever os arquivos da Ajuda em ingl�s, pode-se excluir o diret�rio c:\temp\VB5Help.

