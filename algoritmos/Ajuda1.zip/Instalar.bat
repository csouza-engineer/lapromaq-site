mkdir c:\temp
mkdir c:\temp\vbhelp
extract /E /L c:\Temp\VBhelp help-1.cab
exit

